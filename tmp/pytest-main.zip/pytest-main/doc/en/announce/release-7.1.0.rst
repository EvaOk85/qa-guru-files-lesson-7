pytest-7.1.0
=======================================

The pytest team is proud to announce the 7.1.0 release!

This release contains new features, improvements, and bug fixes,
the full list of changes is available in the changelog:

    https://docs.pytest.org/en/stable/changelog.html

For complete documentation, please visit:

    https://docs.pytest.org/en/stable/

As usual, you can upgrade from PyPI via:

    pip install -U pytest

Thanks to all of the contributors to this release:

* Akuli
* Andrew Svetlov
* Anthony Sottile
* Brett Holman
* Bruno Oliveira
* Chris NeJame
* Dan Alvizu
* Elijah DeLee
* Emmanuel Arias
* Fabian Egli
* Florian Bruhin
* Gabor Szabo
* Hasan Ramezani
* Hugo van Kemenade
* Kian Meng, Ang
* Kojo Idrissa
* Masaru Tsuchiyama
* Olga Matoula
* P. L. Lim
* Ran Benita
* Tobias Deiminger
* Yuval Shimon
* eduardo naufel schettino
* Éric


Happy testing,
The pytest Development Team
